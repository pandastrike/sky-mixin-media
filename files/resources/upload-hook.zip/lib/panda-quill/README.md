# Panda Quill

Panda Quill is a JavaScript library wrapping the Node API in a functional style.

## Installation

`npm i panda-quill`
