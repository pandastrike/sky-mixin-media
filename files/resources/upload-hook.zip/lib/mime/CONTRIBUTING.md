1. Commit messages should have a [Conventional Commit](https://conventionalcommits.org/) prefix.
2. If you're editing the `types/*` files, just stop.  These are auto-generated from [mime-db](https://github.com/jshttp/mime-db).  Go talk to those folks.
3. README edits should be made to [src/README_md.js](src/README_md.js).

Thanks for helping out with this project.  You rock!
