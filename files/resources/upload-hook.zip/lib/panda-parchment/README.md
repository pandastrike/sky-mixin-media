# Panda Parchment

Parchment is a JavaScript library providing a variety of helper functions for dealing with everything from Arrays to Promises in a functional style.

## Installation

`npm i panda-parchment`
